## Quick Things

Joshua Lindsay - 6th August 1996 - Canada



I love music that invokes emotion, and can move people to do meaningful things. Here’s some music I like:



I’m a huge fan of photography and typography.  





## All About Me

I’ve grown up a dreamer and a designer, addicted to creating meaningful things.  When I was a child, I wrote stories about talking animals and created pen & paper roleplaying systems themed around them.  In middle school, my parents bought me a laptop, and I used every spare moment to create: writing more fiction, teaching myself how to use software like Photoshop, and recording music.  All of my life I’ve wanted to use my time and technology to create meaningful things.

## What I’m Doing Now

Today, I’m a Computing Science student at TRU, where I am enjoying formalizing my self-taught skills of problem solving and design.  I’m currently learning Windows & Android application development, working on a pen & paper roleplaying system, 

